# CV1000 headless MAME test environment

Packaged from a working setup used to test a Pink Sweets (CV1000 / SH-3) ROM patch.
No ROMs, NVRAM or save states are included: put your own set in `roms/<set>/` (or `roms/<set>.zip`).

## What's here

| Path | What |
|---|---|
| `bin/cv1k` | MAME **0.289** (official `mame0289` tag, no local changes), `SUBTARGET=cv1k` (only the CV1000 driver), Linux x86_64, built on Ubuntu 24.04 with GCC 13, stripped. Console/log debugger included (`-debug -debugger none`); no Qt debugger window (`USE_QTDEBUG=0`) |
| `bin/LIBS.txt`, `bin/apt_packages.txt` | shared libraries it links against, and the Ubuntu 24.04 packages that provide them |
| `patches/ep1c12_vramdump_0264.patch` | optional debug aid for a 0.264 build only (writes VRAM to `/root/run/vram.raw` once when `/root/run/vramdump.flag` exists). Not applied to the included 0.289 binary |
| `scripts/build_mame.sh [tag]` | rebuilds MAME from https://github.com/mamedev/mame (default tag `mame0289`; older tags such as `mame0264` or `mame0239` work too: it picks the right driver files for each version) |
| `scripts/env.sh` | paths and the headless MAME options (`-video none -sound none -nothrottle -nodrc`, separate nvram/cfg/state/snapshot folders under `work/`) |
| `scripts/boot_test.sh [frames]` | boots the set, snapshots chosen frames (warning screen, title …), logs memory checks |
| `scripts/eeprom_test.sh [frames]` | NVRAM/EEPROM persistence: boots twice from an empty NVRAM folder and compares the saved files |
| `scripts/debug_trace.sh 'cmd' [frames]` | runs with `-debug -debugger none` and issues a debugger command (watchpoint, breakpoint, trace) at a frame; output goes to `work/logs/error.log` |
| `lua/boottest.lua` | the small autoboot script behind the tests (frame count, snapshots, memory dumps, input schedule) |
| `lua/harness.lua` | the larger Pink Sweets test harness (save states in boot and run mode, input schedules, memory dumps, taps, breakpoints, snapshots). Its addresses are Pink Sweets specific; use it as a template for another game |
| `examples/` | real output from this package (see below) |

## Requirements

Ubuntu 24.04 x86_64 (or compatible). To run the included binary:

```
sudo apt install $(cat bin/apt_packages.txt)
```

The binary is built for the 24.04 library versions (`t64` packages). On other distributions, rebuild with `scripts/build_mame.sh`. Building only the cv1k subtarget still compiles the MAME core: about 25 minutes on 2 cores for 0.289.

## Usage

```
export ROMPATH=/path/to/roms       # contains pinkswts/ or pinkswts.zip
export GAME=pinkswts               # any cv1k set name
./scripts/boot_test.sh 1500
BT_SNAP=300,900,1500 BT_MEM="900:0C1066F4:1e" ./scripts/boot_test.sh 1500
./scripts/eeprom_test.sh 1500
BT_DBGAT=800 ./scripts/debug_trace.sh 'wpset 0c3b08fc,4,w,1,{logerror "pc=%08x\n",pc;go}' 1000
```

- `BT_MEM` = `frame:hexaddr:hexlen,...` logs bytes from the SH-3 program space at that frame.
- `BT_SCHED` = file of `frame tokens` lines (`U D L R A B C Q S K V T X`; `Q` = button 4, `S` = 1P start, `K` = coin 1, `V` = service coin, `X` = service/test DIP; `-` = nothing held from that frame on).
- Snapshots go to `work/snap/boot/`, logs to `work/logs/`, NVRAM to `work/nvram/<set>/` (`eeprom`, `nand`).
- MAME saves DIP settings changed by a script into `work/cfg/<set>.cfg`. Delete it if a test left e.g. the service DIP on.

## Example (original Pink Sweets u4, CRC 5d812c9e)

`examples/boot_log_second_boot.txt` (second boot, NVRAM already initialised):

```
boottest: system=pinkswts frames=1500
mem f=300 0c1066f4: 20 20 20 54 48 49 53 20 47 41 4d 45 20 49 53 20 46 4f 52 20 55 53 45 20 49 4e 20 20 20 20
snapshot f=300 ... snapshot f=1500
done f=1500
```

The bytes are the warning text `"   THIS GAME IS FOR USE IN    "` in the unpacked program. `examples/second_boot_snapshots.png` shows frames 300 (loading), 900 (warning screen) and 1500 (title). On a first boot with empty NVRAM the game shows "wait a moment." and initialises its EEPROM/NAND first, so run a test twice when you need the normal boot. All examples were re-made with the included 0.289 binary.

`examples/eeprom_test_output.txt`: the same `eeprom`/`nand` checksums after both runs, so the saved settings persist.

`examples/debug_trace_output.txt`: a write watchpoint on the text layer firing from `pc=0c062336`. The `unmapped internal read/write ... (IRR0)` lines are normal MAME SH-3 log noise.

## Notes

- `-nodrc` (interpreted SH-3) keeps memory taps, watchpoints and per-frame Lua hooks reliable. It is slower, but runs faster than real time headless.
- 0.289 includes the 2026 CV1000 updates: SH7709S cache behaviour for slowdown (March 2026), YMZ770 sound fixes (March 2026), corrected video timings (July 2026) and SH CPU fixes (August/October 2026). Slowdown is closer to the PCB than in older versions, but still treat MAME as a logic/memory/frame-timing tool, not a performance reference for real hardware or MiSTer.
- Save states are not compatible between MAME versions: regenerate them after changing the binary.
- MAME reports a wrong checksum for a patched u4. That is expected.
- MAME is GPL-2.0; source: https://github.com/mamedev/mame (tag `mame0289`), unmodified.
