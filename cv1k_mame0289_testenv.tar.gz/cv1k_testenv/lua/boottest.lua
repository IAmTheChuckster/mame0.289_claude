-- boottest.lua: headless CV1000 boot / memory / screen test for MAME
-- Environment variables (all optional):
--   BT_FRAMES   frames to run before exit (default 1500)
--   BT_SNAP     comma list of frames to snapshot (PNG into -snapshot_directory)
--   BT_MEM      checks "frame:addr:len,..." (hex addr/len, logged as hex bytes)
--   BT_SCHED    input schedule file: lines "frame tokens" (tokens from U D L R A B C Q S K V T X, '-' = none)
--               A B C Q = buttons 1-4, S = 1P start, K = coin 1, V = service coin, T = 2P start, X = service DIP (test mode)
--   BT_LOG      log file (default boottest.log)
local frames = tonumber(os.getenv("BT_FRAMES") or "1500")
local logf = io.open(os.getenv("BT_LOG") or "boottest.log", "w")
local function log(...) logf:write(string.format(...) .. "\n"); logf:flush() end
local function list(s) local t = {} for v in (s or ""):gmatch("[^,]+") do t[#t+1] = v end return t end
local cpu = manager.machine.devices[":maincpu"]
local mem = cpu.spaces["program"]
local function field(port, mask)
  local p = manager.machine.ioport.ports[port]
  if not p then return nil end
  for _, f in pairs(p.fields) do if f.mask == mask then return f end end
end
local F = { U = field(":PORT_D", 0x01), D = field(":PORT_D", 0x02), L = field(":PORT_D", 0x04),
  R = field(":PORT_D", 0x08), A = field(":PORT_D", 0x10), B = field(":PORT_D", 0x20),
  C = field(":PORT_D", 0x40), Q = field(":PORT_D", 0x80), K = field(":PORT_C", 0x04), V = field(":PORT_C", 0x01),
  S = field(":PORT_C", 0x10), T = field(":PORT_C", 0x20), X = field(":DSW", 0x01) }
local sched = {}
if os.getenv("BT_SCHED") then
  for line in io.lines(os.getenv("BT_SCHED")) do
    local f, tok = line:gsub("#.*", ""):match("^%s*(%d+)%s+(%S+)")
    if f then sched[#sched+1] = { tonumber(f), tok } end
  end
end
local snaps = {} for _, v in ipairs(list(os.getenv("BT_SNAP"))) do snaps[tonumber(v)] = true end
local checks = {}
for _, v in ipairs(list(os.getenv("BT_MEM"))) do
  local f, a, l = v:match("(%d+):(%x+):(%x+)")
  if f then checks[#checks+1] = { tonumber(f), tonumber(a, 16), tonumber(l, 16) } end
end
log("boottest: system=%s frames=%d", manager.machine.system.name, frames)
for _, r in pairs(manager.machine.memory.regions) do
  -- ROM region sizes help confirm the set loaded
end
local frame = 0
emu.register_frame_done(function()
  frame = frame + 1
  local tok = "-"
  for _, e in ipairs(sched) do if e[1] <= frame then tok = e[2] end end
  for k, f in pairs(F) do if f then f:set_value(tok:find(k, 1, true) and 1 or 0) end end
  for _, c in ipairs(checks) do
    if c[1] == frame then
      local s = {}
      for i = 0, c[3] - 1 do s[#s+1] = string.format("%02x", mem:read_u8(c[2] + i)) end
      log("mem f=%d %08x: %s", frame, c[2], table.concat(s, " "))
    end
  end
  if snaps[frame] then manager.machine.video:snapshot(); log("snapshot f=%d", frame) end
  if frame % 300 == 0 then log("f=%d pc=%08x", frame, cpu.state["PC"].value) end
  if frame >= frames then log("done f=%d", frame); manager.machine:exit() end
end)
