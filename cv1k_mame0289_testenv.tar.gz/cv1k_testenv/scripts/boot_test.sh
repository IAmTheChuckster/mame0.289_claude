#!/bin/bash
# Boot the set headless, snapshot the warning screen and the title, log memory checks.
# Usage: scripts/boot_test.sh [frames]      (env: GAME, ROMPATH, BT_MEM, BT_SNAP, BT_SCHED)
source "$(dirname "$0")/env.sh"
FR="${1:-1500}"
export BT_FRAMES="$FR" BT_LOG="$WORK/logs/boot_$GAME.log"
export BT_SNAP="${BT_SNAP:-300,900,$FR}"
rm -rf "$WORK/snap/boot"
cd "$WORK/logs" && timeout 900 "$MAME" "$GAME" "${MAME_ARGS[@]}" -snapname "boot/%i" \
  -autoboot_script "$CV1K_ENV/lua/boottest.lua" -log > "$WORK/logs/boot_${GAME}_stdout.txt" 2>&1
rc=$?
echo "exit code $rc"; cat "$BT_LOG"; ls "$WORK/snap/boot" 2>/dev/null
