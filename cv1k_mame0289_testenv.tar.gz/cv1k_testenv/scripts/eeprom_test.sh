#!/bin/bash
# EEPROM / NVRAM persistence: boot once with an empty NVRAM folder (the game writes its
# defaults), then boot again and check the saved files are reused unchanged.
source "$(dirname "$0")/env.sh"
FR="${1:-1200}"
rm -rf "$WORK/nvram/$GAME"
export BT_FRAMES="$FR" BT_SNAP=""
for run in 1 2; do
  BT_LOG="$WORK/logs/eeprom_run$run.log" timeout 900 "$MAME" "$GAME" "${MAME_ARGS[@]}" \
    -autoboot_script "$CV1K_ENV/lua/boottest.lua" > /dev/null 2>&1
  echo "after run $run:"; (cd "$WORK/nvram/$GAME" 2>/dev/null && md5sum * ) || echo "  no nvram files"
done
