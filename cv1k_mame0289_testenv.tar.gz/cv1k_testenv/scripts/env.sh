# Source this file. Paths default to this package; override with environment variables.
CV1K_ENV="${CV1K_ENV:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
MAME="${MAME:-$CV1K_ENV/bin/cv1k}"            # MAME binary (cv1k subtarget)
GAME="${GAME:-pinkswts}"                        # MAME set name
ROMPATH="${ROMPATH:-$CV1K_ENV/roms}"            # folder containing <GAME>/ (or <GAME>.zip)
WORK="${WORK:-$CV1K_ENV/work}"                  # nvram, cfg, states, snapshots, logs
mkdir -p "$WORK"/{nvram,cfg,sta,snap,logs}
# Headless, unthrottled, interpreter CPU (-nodrc: needed for reliable Lua memory taps/debugger)
MAME_ARGS=(-rompath "$ROMPATH" -video none -sound none -nothrottle -skip_gameinfo -nodrc
  -seconds_to_run 0 -nvram_directory "$WORK/nvram" -cfg_directory "$WORK/cfg"
  -state_directory "$WORK/sta" -snapshot_directory "$WORK/snap")
