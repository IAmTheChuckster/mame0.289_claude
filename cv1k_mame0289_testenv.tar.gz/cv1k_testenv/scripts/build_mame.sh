#!/bin/bash
# Build MAME with only the CV1000 driver (headless test build, no Qt debugger window;
# the console/log debugger used by the scripts is included).
# Usage: scripts/build_mame.sh [tag]      e.g. mame0289 (default), mame0264, mame0239
set -e
PKG="$(cd "$(dirname "$0")/.." && pwd)"
TAG="${1:-mame0289}"
sudo apt-get install -y git build-essential python3 libsdl2-dev libsdl2-ttf-dev \
  libfontconfig1-dev libpulse-dev libasound2-dev libxinerama-dev libxi-dev || true
DIR="mame-$TAG"
[ -d "$DIR" ] || git clone --depth 1 --branch "$TAG" https://github.com/mamedev/mame.git "$DIR"
cd "$DIR"
# the driver moved in 0.251: src/mame/drivers/cv1k.cpp -> src/mame/cave/cv1k.cpp;
# newer versions split the blitter into src/mame/cave/cv1k_v_blit*.cpp, which must be listed too
if [ -f src/mame/cave/cv1k.cpp ]; then SRC=src/mame/cave/cv1k.cpp; else SRC=src/mame/drivers/cv1k.cpp; fi
for f in src/mame/cave/cv1k_v_blit*.cpp; do [ -f "$f" ] && SRC="$SRC,$f"; done
# optional VRAM dump hook (0.264 only; harmless to skip)
[ "$TAG" = mame0264 ] && git apply "$PKG"/patches/ep1c12_vramdump_0264.patch 2>/dev/null || true
# USE_QTDEBUG=0: recent versions need Qt 6 for the debugger window; not needed headless
make -j"$(nproc)" SUBTARGET=cv1k SOURCES="$SRC" NOWERROR=1 TOOLS=0 NO_USE_PORTAUDIO=1 USE_QTDEBUG=0
ls -la cv1k*
