#!/bin/bash
# Run with the MAME debugger (no UI) and a command script, e.g. a watchpoint that logs to
# error.log:  scripts/debug_trace.sh 'wpset 0c49c5e4,4,w,1,{logerror "W pc=%08x\n",pc;go}'
# The command is issued at frame BT_DBGAT (default 600) through the Lua script.
source "$(dirname "$0")/env.sh"
CMD="$1"; AT="${BT_DBGAT:-600}"; FR="${2:-900}"
cat > "$WORK/dbg.lua" <<L
local f=0
emu.register_frame_done(function() f=f+1
  if f==$AT then manager.machine.debugger:command([[$CMD]]); manager.machine.debugger:command("go") end
  if f>=$FR then manager.machine:exit() end end)
L
cd "$WORK/logs" && timeout 1800 "$MAME" "$GAME" "${MAME_ARGS[@]}" -debug -debugger none -log \
  -autoboot_script "$WORK/dbg.lua" > /dev/null 2>&1
grep -a -v "^$" error.log | tail -20
